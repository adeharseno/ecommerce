<?php $__env->startSection('title', 'Produk — ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        
        <div class="mb-8">
            <p class="text-xs font-semibold tracking-[0.2em] uppercase text-stone-400 mb-1">Koleksi</p>
            <h1 class="text-3xl font-bold text-stone-900">Semua Produk</h1>
        </div>

        
        <form method="GET" action="<?php echo e(route('products.index')); ?>"
              class="flex flex-wrap gap-3 mb-10">

            <input type="text"
                   name="search"
                   value="<?php echo e(request('search')); ?>"
                   placeholder="Cari produk..."
                   class="flex-1 min-w-[200px] px-4 py-2 border border-stone-300 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-stone-400">

            <?php if($categories->isNotEmpty()): ?>
                <select name="category"
                        class="px-4 py-2 border border-stone-300 rounded-full text-sm bg-white focus:outline-none focus:ring-2 focus:ring-stone-400">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat); ?>" <?php if(request('category') === $cat): echo 'selected'; endif; ?>>
                            <?php echo e(ucfirst($cat)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>

            <button type="submit"
                    class="px-5 py-2 bg-stone-900 text-white text-sm font-semibold rounded-full hover:bg-stone-700 transition-colors">
                Cari
            </button>

            <?php if(request()->hasAny(['search', 'category'])): ?>
                <a href="<?php echo e(route('products.index')); ?>"
                   class="px-5 py-2 border border-stone-300 text-stone-600 text-sm font-medium rounded-full hover:bg-stone-100 transition-colors">
                    Reset
                </a>
            <?php endif; ?>
        </form>

        
        <?php if($products->isEmpty()): ?>
            <div class="text-center py-24 text-stone-400">
                <svg class="w-12 h-12 mx-auto mb-4 text-stone-300" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 13.5h3.86a2.25 2.25 0 0 1 2.012 1.244l.256.512a2.25 2.25 0 0 0 2.013 1.244h3.218a2.25 2.25 0 0 0 2.013-1.244l.256-.512a2.25 2.25 0 0 1 2.013-1.244h3.859m-19.5.338V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18v-4.162c0-.224-.034-.447-.1-.661L19.24 5.338a2.25 2.25 0 0 0-2.15-1.588H6.911a2.25 2.25 0 0 0-2.15 1.588L2.35 13.177a2.25 2.25 0 0 0-.1.661Z"/>
                </svg>
                <p class="text-lg font-medium">Produk tidak ditemukan.</p>
                <p class="text-sm mt-1">Coba ubah kata kunci atau filter pencarian Anda.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="group block">
                        <div class="aspect-square overflow-hidden rounded-xl bg-stone-100 mb-3 relative">
                            <img src="<?php echo e($product->getFirstImageUrl()); ?>"
                                 alt="<?php echo e($product->name); ?>"
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                            <?php if($product->stock === 0): ?>
                                <div class="absolute inset-0 bg-white/60 flex items-center justify-center">
                                    <span class="text-xs font-bold uppercase tracking-widest text-stone-500 bg-white px-3 py-1 rounded-full border border-stone-300">
                                        Habis
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="space-y-1">
                            <?php if($product->category): ?>
                                <p class="text-[11px] font-medium uppercase tracking-widest text-stone-400">
                                    <?php echo e($product->category); ?>

                                </p>
                            <?php endif; ?>
                            <h3 class="text-sm font-semibold text-stone-800 group-hover:text-stone-600 transition-colors line-clamp-2">
                                <?php echo e($product->name); ?>

                            </h3>
                            <p class="text-sm font-bold text-stone-900">
                                Rp <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?>

                            </p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <?php if($products->hasPages()): ?>
                <div class="mt-12 flex justify-center">
                    <?php echo e($products->links()); ?>

                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('themes.briquet.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /mnt/d/projects/e-commerce-template/laravel-ecommerce/resources/views/themes/briquet/products/index.blade.php ENDPATH**/ ?>